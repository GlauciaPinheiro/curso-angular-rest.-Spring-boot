package com.example.algamoney.api.service.exception;

public class PessoaInexistenteOuInativaException extends RuntimeException {

	private static final long serialVersionUID = 1L;

}